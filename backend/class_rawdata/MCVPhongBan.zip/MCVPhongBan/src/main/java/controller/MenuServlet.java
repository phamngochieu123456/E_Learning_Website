package controller;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Department;
import model.bean.Employee;
import model.bean.User;
import model.bo.MenuListBO;
@WebServlet("/MenuServlet")
public class MenuServlet extends HttpServlet{
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException,IOException{
        doPost(request, response);
}
    protected void doPost(HttpServletRequest request,
	     HttpServletResponse response)throws ServletException,IOException{
	   String destination=null;
   
	   String button = request.getParameter("button");

	  MenuListBO menuListBO=new MenuListBO();
	  if ("View Employees's Data".equals(button)) {
		  ArrayList<Employee> employeeArray = menuListBO.getEmployeeList();
		  request.setAttribute("EmployeeList", employeeArray);
	      destination="/viewAllEmployee.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if ("View Department's Data".equals(button)) {
		  ArrayList<Department> department = menuListBO.getDepartmentList();
		  request.setAttribute("DepartmentList", department);
	      destination="/viewAllDepartments.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if ("Modify Department's Data".equals(button)) {
		  ArrayList<Department> department = menuListBO.getDepartmentList();
		  request.setAttribute("DepartmentList", department);
	      destination="/modifyDepartment.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if ("Search Employee".equals(button)){
		   destination="/searchEmployee.jsp";
		   RequestDispatcher rd=getServletContext().getRequestDispatcher(
			        destination);
		   rd.forward(request,response);
      } else if ("Search".equals(button)){
		  ArrayList<Employee> employeeArray = menuListBO.searchEmployee(request.getParameter("column"),request.getParameter("data"));
		  request.setAttribute("EmployeeList", employeeArray);
	      destination="/viewAllEmployee.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if ("Logout".equals(button)){
		   destination="/login.jsp";
		   RequestDispatcher rd=getServletContext().getRequestDispatcher(
			        destination);
		   rd.forward(request,response);
      } else if ("Update".equals(button)){
		   String IDNV = request.getParameter("txt_IDNV");
		   String Hoten = request.getParameter("txt_Hoten");
		   String IDPB = request.getParameter("txt_IDPB");
		   String DiaChi = request.getParameter("txt_DiaChi");
		   Employee emp = new Employee();
		   emp.setIDNV(IDNV);
		   emp.setHoten(Hoten);
		   emp.setIDPB(IDPB);
		   emp.setDiaChi(DiaChi);
		   if(menuListBO.updateEmployeeByID(emp)) {
			   ArrayList<Employee> employeeArray = menuListBO.getEmployeeListByDepartmentID(IDPB);
			   request.setAttribute("EmployeeList", employeeArray);
			   destination="/viewEmployeeByDepartmentID.jsp";
			   RequestDispatcher rd=getServletContext().getRequestDispatcher(
				        destination);
			   rd.forward(request,response);
		   }
       } else if ("Update Department".equals(button)){
		   String IDPB = request.getParameter("txt_IDPB");
		   String Tenpb = request.getParameter("txt_Tenpb");
		   String Mota = request.getParameter("txt_Mota");
		   Department dep = new Department();
		   dep.setIDPB(IDPB);
		   dep.setTenpb(Tenpb);
		   dep.setMota(Mota);
		   if(menuListBO.updateDepartmentByID(dep)) {
			   ArrayList<Department> department = menuListBO.getDepartmentList();
			   request.setAttribute("DepartmentList", department);
		       destination="/modifyDepartment.jsp";
		       RequestDispatcher rd=getServletContext().getRequestDispatcher(
		           destination);
		       rd.forward(request,response);
		   }
       } else if ("Insert".equals(button)){
		   String IDNV = request.getParameter("txt_IDNV");
		   String Hoten = request.getParameter("txt_Hoten");
		   String IDPB = request.getParameter("txt_IDPB");
		   String DiaChi = request.getParameter("txt_DiaChi");
		   Employee emp = new Employee();
		   emp.setIDNV(IDNV);
		   emp.setHoten(Hoten);
		   emp.setIDPB(IDPB);
		   emp.setDiaChi(DiaChi);
		   if(menuListBO.insertEmployee(emp)) {
			   ArrayList<Employee> employeeArray = menuListBO.getEmployeeListByDepartmentID(IDPB);
			   request.setAttribute("EmployeeList", employeeArray);
			   destination="/viewEmployeeByDepartmentID.jsp";
			   RequestDispatcher rd=getServletContext().getRequestDispatcher(
				        destination);
			   rd.forward(request,response);
		   }
      } else if ("Insert Depart".equals(button)){
    	   String IDPB = request.getParameter("txt_IDPB");
		   String Tenpb = request.getParameter("txt_Tenpb");
		   String Mota = request.getParameter("txt_Mota");
		   Department dep = new Department();
		   dep.setIDPB(IDPB);
		   dep.setTenpb(Tenpb);
		   dep.setMota(Mota);
		   if(menuListBO.insertDepartment(dep)) {
			   ArrayList<Department> department = menuListBO.getDepartmentList();
			   request.setAttribute("DepartmentList", department);
		       destination="/modifyDepartment.jsp";
		       RequestDispatcher rd=getServletContext().getRequestDispatcher(
		           destination);
		       rd.forward(request,response);
		   }
      } else if ("Insert Employee".equals(button)){
	      destination="/insertEmployee.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if ("Insert Department".equals(button)){
	      destination="/insertDepartment.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if (request.getParameter("IDNV") != null&&request.getParameter("delete") != null){
		   if(menuListBO.deleteEmployeeByID(request.getParameter("IDNV"))) {
			   ArrayList<Employee> employeeArray = menuListBO.getEmployeeListByDepartmentID(request.getParameter("delete"));
			   request.setAttribute("EmployeeList", employeeArray);
			   destination="/viewEmployeeByDepartmentID.jsp";
			   RequestDispatcher rd=getServletContext().getRequestDispatcher(
				        destination);
			   rd.forward(request,response);
		   }
      } else if (request.getParameter("IDPB") != null&&request.getParameter("delete") != null){
		   if(menuListBO.deleteDepartmentByID(request.getParameter("IDPB"))) {
			   ArrayList<Department> department = menuListBO.getDepartmentList();
			   request.setAttribute("DepartmentList", department);
		       destination="/modifyDepartment.jsp";
		       RequestDispatcher rd=getServletContext().getRequestDispatcher(
		           destination);
		       rd.forward(request,response);
		   }
      } else if (request.getParameter("IDNV") != null&&request.getParameter("update") != null){
		  Employee employee = menuListBO.getEmployeeByID(request.getParameter("IDNV"));
		  request.setAttribute("Employee", employee);
	      destination="/updateEmployee.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if (request.getParameter("IDPB") != null&&request.getParameter("update") != null){
    	  Department dep = menuListBO.getDepartmentByID(request.getParameter("IDPB"));
		  request.setAttribute("Department", dep);
	      destination="/updateDepartment.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else if (request.getParameter("IDPB") != null){
		  ArrayList<Employee> employeeArray = menuListBO.getEmployeeListByDepartmentID(request.getParameter("IDPB"));
		  request.setAttribute("EmployeeList", employeeArray);
	      destination="/viewEmployeeByDepartmentID.jsp";
	      RequestDispatcher rd=getServletContext().getRequestDispatcher(
	           destination);
	      rd.forward(request,response);
      } else {
		   destination="/menuList.jsp";
		   RequestDispatcher rd=getServletContext().getRequestDispatcher(
			        destination);
		   rd.forward(request,response);
      }
	  
   }}