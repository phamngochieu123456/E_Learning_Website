package model.bean;
public class Department{
    private String IDPB;
    private String Tenpb;
    private String Mota;
    private String active;
	public String getIDPB() {
		return IDPB;
	}
	public void setIDPB(String iDPB) {
		IDPB = iDPB;
	}
	public String getTenpb() {
		return Tenpb;
	}
	public void setTenpb(String tenpb) {
		Tenpb = tenpb;
	}
	public String getMota() {
		return Mota;
	}
	public void setMota(String mota) {
		Mota = mota;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}

}