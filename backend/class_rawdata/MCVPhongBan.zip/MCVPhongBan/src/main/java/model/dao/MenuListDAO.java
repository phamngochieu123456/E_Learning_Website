package model.dao;
import java.util.ArrayList;

import model.bean.Department;
import model.bean.Employee;

import java.sql.*;
public class MenuListDAO{
    public ArrayList<Employee> getEmployeeList(){
        ArrayList<Employee>result = new ArrayList<Employee>();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	Statement sm=conn.createStatement();
        	String sql="select * from nhanvien where active='1'";
        	//truy van thong tin tu bang nhanvien
        	ResultSet rs=sm.executeQuery(sql);
        	while(rs.next()){
        		Employee emp = new Employee();
        		emp.setIDNV(rs.getString(1));
        		emp.setHoten(rs.getString(2));
        		emp.setIDPB(rs.getString(3));
        		emp.setDiaChi(rs.getString(4));
        		emp.setActive(rs.getString(5));
        		result.add(emp);
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
    public ArrayList<Employee> getEmployeeListByDepartmentID(String IDPB){
        ArrayList<Employee>result = new ArrayList<Employee>();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("select * from nhanvien where active='1' and IDPB=?");
        	sql.setString(1, IDPB);
        	ResultSet rs=sql.executeQuery();
        	while(rs.next()){
        		Employee emp = new Employee();
        		emp.setIDNV(rs.getString(1));
        		emp.setHoten(rs.getString(2));
        		emp.setIDPB(rs.getString(3));
        		emp.setDiaChi(rs.getString(4));
        		emp.setActive(rs.getString(5));
        		result.add(emp);
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
    public ArrayList<Employee> searchEmployee(String column, String data){
        ArrayList<Employee>result = new ArrayList<Employee>();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
    		Statement sm=conn.createStatement();
        	String sql="select * from nhanvien where "+column+" like '"+data+"' and active='1'";
        	//truy van thong tin tu bang nhanvien
        	ResultSet rs=sm.executeQuery(sql);
    		System.out.println(sql);

        	while(rs.next()){
        		Employee emp = new Employee();
        		emp.setIDNV(rs.getString(1));
        		emp.setHoten(rs.getString(2));
        		emp.setIDPB(rs.getString(3));
        		emp.setDiaChi(rs.getString(4));
        		emp.setActive(rs.getString(5));
        		result.add(emp);
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
    public Employee getEmployeeByID(String IDNV){
        Employee result = new Employee();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("select * from nhanvien where active='1' and IDNV=?");
        	sql.setString(1, IDNV);
        	ResultSet rs=sql.executeQuery();
        	while(rs.next()){
        		Employee emp = new Employee();
        		emp.setIDNV(rs.getString(1));
        		emp.setHoten(rs.getString(2));
        		emp.setIDPB(rs.getString(3));
        		emp.setDiaChi(rs.getString(4));
        		emp.setActive(rs.getString(5));
        		result = emp;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
    public Department getDepartmentByID(String IDPB){
    	Department result = new Department();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("select * from phongban where active='1' and IDPB=?");
        	sql.setString(1, IDPB);
        	ResultSet rs=sql.executeQuery();
        	while(rs.next()){
        		Department dep = new Department();
        		dep.setIDPB(rs.getString(1));
        		dep.setTenpb(rs.getString(2));
        		dep.setMota(rs.getString(3));
        		result = dep;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
    public boolean insertEmployee(Employee emp){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("insert into nhanvien values(?,?,?,?,'1')");
        	sql.setString(1, emp.getIDNV());
        	sql.setString(2, emp.getHoten());
        	sql.setString(3, emp.getIDPB());
        	sql.setString(4, emp.getDiaChi());
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public boolean insertDepartment(Department dep){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("insert into phongban values(?,?,?,'1')");
        	sql.setString(1, dep.getIDPB());
        	sql.setString(2, dep.getTenpb());
        	sql.setString(3, dep.getMota());
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public boolean updateEmployeeByID(Employee emp){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("update nhanvien set Hoten =?, IDPB =?, DiaChi =? where IDNV =?");
        	sql.setString(1, emp.getHoten());
        	sql.setString(2, emp.getIDPB());
        	sql.setString(3, emp.getDiaChi());
        	sql.setString(4, emp.getIDNV());
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public boolean deleteEmployeeByID(String IDNV){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("update nhanvien set active ='0' where IDNV =?");
        	sql.setString(1, IDNV);
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public boolean updateDepartmentByID(Department dep){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("update phongban set Tenpb =?, Mota =? where IDPB =?");
        	sql.setString(1, dep.getTenpb());
        	sql.setString(2, dep.getMota());
        	sql.setString(3, dep.getIDPB());
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public boolean deleteDepartmentByID(String IDPB){
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("update phongban set active ='0' where IDPB =?");
        	sql.setString(1, IDPB);
        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }
    public ArrayList<Department> getDepartmentList(){
        ArrayList<Department>result = new ArrayList<Department>();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	Statement sm=conn.createStatement();
        	String sql="select * from phongban where active='1'";
        	//truy van thong tin tu bang nhanvien
        	ResultSet rs=sm.executeQuery(sql);
        	while(rs.next()){
        		Department dep = new Department();
        		dep.setIDPB(rs.getString(1));
        		dep.setTenpb(rs.getString(2));
        		dep.setMota(rs.getString(3));
        		dep.setActive(rs.getString(4));
        		result.add(dep);
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
    	return result;
    }
}