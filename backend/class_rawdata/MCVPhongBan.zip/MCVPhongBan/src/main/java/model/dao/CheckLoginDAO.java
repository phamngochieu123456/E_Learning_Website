package model.dao;
import java.util.ArrayList;
import model.bean.User;
import java.sql.Connection; 
import java.sql.*;   
import java.sql.Statement;
import java.sql.DriverManager; 
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
public class CheckLoginDAO{
    public String isExistUser(String userName,String password){
        // Connect vao Database lam mo so viec
        // Tat ca nhung cau SQL deu phai datoDAO
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	Statement sm=conn.createStatement();
        	String sql="select * from test123";
        	//truy van thong tin tu bang test123
        	ResultSet rs=sm.executeQuery(sql);
        	while(rs.next()){
        		if((userName.equals(rs.getString(2)) && password.equals(rs.getString(3)))){
        			return rs.getString(5);
        		}
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return null;
    }
    public ArrayList<User>getWifeList(String userName){
        ArrayList<User>result = new ArrayList<User>();
        // Connect vao Database lam mo so viec
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	Statement sm=conn.createStatement();
        	String sql="select * from wife";
        	//truy van thong tin tu bang adimn
        	ResultSet rs=sm.executeQuery(sql);
        	while(rs.next()){
        		User wife = new User();
//        		wife.setName(rs.getString(1));
//        		wife.setAddress(rs.getString(2));
//        		wife.setAlive(rs.getBoolean(3));
        		result.add(wife);
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	
		return result;
}}