package model.bo;
import model.dao.RegisterDAO;
public class RegisterBO{
	RegisterDAO registerDAO=new RegisterDAO();
    public boolean insertUser(String role, String userName,String password, String firstname, String lastname){
        return registerDAO.insertUser(role,userName,password,firstname,lastname);
    }
}