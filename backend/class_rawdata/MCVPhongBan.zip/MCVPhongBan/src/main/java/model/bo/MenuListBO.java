package model.bo;
import java.util.ArrayList;

import model.bean.Department;
import model.bean.Employee;
import model.dao.MenuListDAO;
public class MenuListBO{
	MenuListDAO menuListDAO=new MenuListDAO();
    public ArrayList<Employee> getEmployeeList(){
        return menuListDAO.getEmployeeList();
    }
    public ArrayList<Employee> searchEmployee(String column, String data){
        return menuListDAO.searchEmployee(column, data);
    }
    public ArrayList<Employee> getEmployeeListByDepartmentID(String IDPB){
        return menuListDAO.getEmployeeListByDepartmentID(IDPB);
    }
    public Employee getEmployeeByID(String IDNV){
        return menuListDAO.getEmployeeByID(IDNV);
    }
    public Department getDepartmentByID(String IDPB){
        return menuListDAO.getDepartmentByID(IDPB);
    }
    public boolean insertEmployee(Employee emp){
        return menuListDAO.insertEmployee(emp);
    }
    public boolean insertDepartment(Department dep){
        return menuListDAO.insertDepartment(dep);
    }
    public boolean updateEmployeeByID(Employee emp){
        return menuListDAO.updateEmployeeByID(emp);
    }
    public boolean deleteEmployeeByID(String IDNV){
        return menuListDAO.deleteEmployeeByID(IDNV);
    }
    public boolean updateDepartmentByID(Department dep){
        return menuListDAO.updateDepartmentByID(dep);
    }
    public boolean deleteDepartmentByID(String IDPB){
        return menuListDAO.deleteDepartmentByID(IDPB);
    }
    public ArrayList<Department> getDepartmentList(){
        return menuListDAO.getDepartmentList();
    }
    
}