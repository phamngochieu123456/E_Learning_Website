package model.dao;
import java.util.ArrayList;
import model.bean.User;

import java.io.Console;
import java.sql.*;
public class RegisterDAO{
    public boolean insertUser(String role, String userName,String password, String firstname, String lastname){
        // Connect vao Database lam mo so viec
        // Tat ca nhung cau SQL deu phai datoDAO
    	try{
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
        	PreparedStatement sql=conn.prepareStatement("INSERT INTO test123(role, username, password, firstname, lastname) VALUES (?,?,?,?,?)");
        	//truy van thong tin tu bang test123
        	sql.setString(1, role);
        	sql.setString(2, userName);
        	sql.setString(3, password);
        	sql.setString(4, firstname);
        	sql.setString(5, lastname);

        	int rs=sql.executeUpdate();
        	if (rs!=0) {
        		return true;
        	}
        	
        }catch(Exception e){System.out.print(e);
        	
        }
    	return false;
    }}