package model.bean;
public class User{
    private String role;
    private String username;
    private String password;
    private String firstname;
    private String lastname;

    public String getrole(){
        return role;
    }
    public void setRole(String role){
        this.role=role;
   }
    public String getusername(){
        return username;
    }
    public void setusername(String username){
        this.username=username;
   }
    public String getpassword(){
        return password;
    }
    public void setpassword(String password){
        this.password=password;
   }
    public String getfirstname(){
        return firstname;
    }
    public void setfirstname(String firstname){
        this.firstname=firstname;
   }
    public String getlastname(){
        return lastname;
    }
    public void setlastname(String lastname){
        this.lastname=lastname;
   }
}